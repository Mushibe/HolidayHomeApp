package com.holidayhome.user.service;

import com.holidayhome.user.dto.UserRequestDTO;
import com.holidayhome.user.dto.UserResponseDTO;
import com.holidayhome.user.entity.UserProfileEntity;
import com.holidayhome.user.exception.UserNotFoundException;
import com.holidayhome.user.mapper.UserMapper;
import com.holidayhome.user.repository.UserProfileRepository;
import com.holidayhome.user.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserProfileRepository userRepository;

    @Mock
    private UserMapper userMapper;

    @InjectMocks
    private UserServiceImpl userService;

    private UserProfileEntity userEntity;
    private UserRequestDTO userDTO;
    private UserResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        userEntity = UserProfileEntity.builder()
                .id(1L)
                .username("john_doe")
                .email("john@example.com")
                .fullName("John Doe")
                .phoneNumber("+1-555-0192")
                .address("Miami, FL")
                .build();

        userDTO = UserRequestDTO.builder()
                .username("john_doe")
                .email("john@example.com")
                .fullName("John Doe")
                .phoneNumber("+1-555-0192")
                .address("Miami, FL")
                .build();

        responseDTO = UserResponseDTO.builder()
                .id(1L)
                .username("john_doe")
                .email("john@example.com")
                .fullName("John Doe")
                .phoneNumber("+1-555-0192")
                .address("Miami, FL")
                .build();
    }

    @Test
    void createUserProfile_Success() {
        when(userRepository.existsByUsername("john_doe")).thenReturn(false);
        when(userMapper.toEntity(any())).thenReturn(userEntity);
        when(userRepository.save(any())).thenReturn(userEntity);
        when(userMapper.toDTO(any())).thenReturn(responseDTO);

        UserResponseDTO result = userService.createUserProfile(userDTO);

        assertNotNull(result);
        assertEquals("john_doe", result.getUsername());
    }

    @Test
    void getUserProfileById_Success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(userEntity));
        when(userMapper.toDTO(userEntity)).thenReturn(responseDTO);

        UserResponseDTO result = userService.getUserProfileById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    @Test
    void getUserProfileById_NotFound_ThrowsException() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> userService.getUserProfileById(99L));
    }
}
