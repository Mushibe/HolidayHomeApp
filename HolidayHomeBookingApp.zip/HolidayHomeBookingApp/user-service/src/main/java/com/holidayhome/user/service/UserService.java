package com.holidayhome.user.service;

import com.holidayhome.user.dto.UserRequestDTO;
import com.holidayhome.user.dto.UserResponseDTO;

import java.util.List;

public interface UserService {

    UserResponseDTO createUserProfile(UserRequestDTO requestDTO);

    UserResponseDTO getUserProfileById(Long id);

    UserResponseDTO getUserProfileByUsername(String username);

    List<UserResponseDTO> getAllUserProfiles();

    UserResponseDTO updateUserProfile(Long id, UserRequestDTO requestDTO);
}
