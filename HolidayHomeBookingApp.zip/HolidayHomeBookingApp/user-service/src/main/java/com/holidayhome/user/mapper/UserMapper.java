package com.holidayhome.user.mapper;

import com.holidayhome.user.dto.UserRequestDTO;
import com.holidayhome.user.dto.UserResponseDTO;
import com.holidayhome.user.entity.UserProfileEntity;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public UserProfileEntity toEntity(UserRequestDTO dto) {
        if (dto == null) {
            return null;
        }
        return UserProfileEntity.builder()
                .username(dto.getUsername())
                .email(dto.getEmail())
                .fullName(dto.getFullName())
                .phoneNumber(dto.getPhoneNumber())
                .address(dto.getAddress())
                .build();
    }

    public UserResponseDTO toDTO(UserProfileEntity entity) {
        if (entity == null) {
            return null;
        }
        return UserResponseDTO.builder()
                .id(entity.getId())
                .username(entity.getUsername())
                .email(entity.getEmail())
                .fullName(entity.getFullName())
                .phoneNumber(entity.getPhoneNumber())
                .address(entity.getAddress())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }
}
