package com.holidayhome.user.service.impl;

import com.holidayhome.user.dto.UserRequestDTO;
import com.holidayhome.user.dto.UserResponseDTO;
import com.holidayhome.user.entity.UserProfileEntity;
import com.holidayhome.user.exception.DuplicateUserException;
import com.holidayhome.user.exception.UserNotFoundException;
import com.holidayhome.user.mapper.UserMapper;
import com.holidayhome.user.repository.UserProfileRepository;
import com.holidayhome.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserProfileRepository userRepository;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public UserResponseDTO createUserProfile(UserRequestDTO requestDTO) {
        log.info("Creating user profile for username: {}", requestDTO.getUsername());

        if (userRepository.existsByUsername(requestDTO.getUsername())) {
            throw new DuplicateUserException("Profile for username '" + requestDTO.getUsername() + "' already exists");
        }

        UserProfileEntity entity = userMapper.toEntity(requestDTO);
        UserProfileEntity savedEntity = userRepository.save(entity);
        log.info("User profile created with ID: {}", savedEntity.getId());

        return userMapper.toDTO(savedEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponseDTO getUserProfileById(Long id) {
        log.info("Fetching user profile by ID: {}", id);
        UserProfileEntity entity = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User profile not found with ID: " + id));
        return userMapper.toDTO(entity);
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponseDTO getUserProfileByUsername(String username) {
        log.info("Fetching user profile by username: {}", username);
        UserProfileEntity entity = userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User profile not found with username: " + username));
        return userMapper.toDTO(entity);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserResponseDTO> getAllUserProfiles() {
        log.info("Fetching all user profiles");
        return userRepository.findAll().stream()
                .map(userMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public UserResponseDTO updateUserProfile(Long id, UserRequestDTO requestDTO) {
        log.info("Updating user profile for ID: {}", id);

        UserProfileEntity existing = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User profile not found with ID: " + id));

        existing.setFullName(requestDTO.getFullName());
        existing.setEmail(requestDTO.getEmail());
        existing.setPhoneNumber(requestDTO.getPhoneNumber());
        existing.setAddress(requestDTO.getAddress());

        UserProfileEntity updated = userRepository.save(existing);
        log.info("User profile updated successfully for ID: {}", updated.getId());

        return userMapper.toDTO(updated);
    }
}
