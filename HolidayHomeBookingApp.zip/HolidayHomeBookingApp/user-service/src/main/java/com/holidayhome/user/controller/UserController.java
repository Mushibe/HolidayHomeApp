package com.holidayhome.user.controller;

import com.holidayhome.user.dto.ApiResponse;
import com.holidayhome.user.dto.UserRequestDTO;
import com.holidayhome.user.dto.UserResponseDTO;
import com.holidayhome.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@Tag(name = "User Management Controller", description = "Endpoints for managing user profiles")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;

    @PostMapping
    @Operation(summary = "Create user profile", description = "Creates a detailed user profile")
    public ResponseEntity<ApiResponse<UserResponseDTO>> createUserProfile(@Valid @RequestBody UserRequestDTO requestDTO) {
        log.info("REST request to create user profile for: {}", requestDTO.getUsername());
        UserResponseDTO created = userService.createUserProfile(requestDTO);
        return new ResponseEntity<>(ApiResponse.success("User profile created successfully", created), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all users", description = "Retrieves a list of all registered user profiles")
    public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getAllUsers() {
        log.info("REST request to get all user profiles");
        List<UserResponseDTO> users = userService.getAllUserProfiles();
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", users));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get user by ID", description = "Retrieves a single user profile by its ID")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(@PathVariable Long id) {
        log.info("REST request to get user profile by ID: {}", id);
        UserResponseDTO user = userService.getUserProfileById(id);
        return ResponseEntity.ok(ApiResponse.success("User retrieved successfully", user));
    }

    @GetMapping("/username")
    @Operation(summary = "Get user by Username", description = "Retrieves a user profile by username query parameter")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserByUsername(@RequestParam String username) {
        log.info("REST request to get user profile by username: {}", username);
        UserResponseDTO user = userService.getUserProfileByUsername(username);
        return ResponseEntity.ok(ApiResponse.success("User retrieved successfully", user));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update user profile", description = "Updates profile details of an existing user")
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateUserProfile(
            @PathVariable Long id,
            @Valid @RequestBody UserRequestDTO requestDTO) {
        log.info("REST request to update user profile for ID: {}", id);
        UserResponseDTO updated = userService.updateUserProfile(id, requestDTO);
        return ResponseEntity.ok(ApiResponse.success("User profile updated successfully", updated));
    }
}
