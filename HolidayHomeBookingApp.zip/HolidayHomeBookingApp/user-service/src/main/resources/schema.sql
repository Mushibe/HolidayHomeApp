-- User Database Schema Script

CREATE TABLE IF NOT EXISTS user_profiles (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    address VARCHAR(255),
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Seed Sample User Profiles
INSERT INTO user_profiles (username, email, full_name, phone_number, address)
VALUES 
('john_doe', 'john@example.com', 'John Doe', '+1-555-0192', '123 Palm Street, Miami, FL'),
('alice_smith', 'alice@example.com', 'Alice Smith', '+1-555-0183', '456 Ocean Drive, Los Angeles, CA')
ON CONFLICT (username) DO NOTHING;
