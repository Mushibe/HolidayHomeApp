package com.holidayhome.recommendation.service;

import com.holidayhome.recommendation.client.PropertyClient;
import com.holidayhome.recommendation.client.UserClient;
import com.holidayhome.recommendation.dto.ApiResponse;
import com.holidayhome.recommendation.dto.PropertyDTO;
import com.holidayhome.recommendation.dto.RecommendationResponseDTO;
import com.holidayhome.recommendation.service.impl.RecommendationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RecommendationServiceTest {

    @Mock
    private PropertyClient propertyClient;

    @Mock
    private UserClient userClient;

    @InjectMocks
    private RecommendationServiceImpl recommendationService;

    private PropertyDTO property1;

    @BeforeEach
    void setUp() {
        property1 = PropertyDTO.builder()
                .id(1L)
                .name("Ocean Villa")
                .location("Malibu")
                .build();
    }

    @Test
    void getRecommendations_Success() {
        ApiResponse<List<PropertyDTO>> apiResponse = ApiResponse.success("Ok", List.of(property1));
        when(propertyClient.getAllProperties()).thenReturn(apiResponse);

        List<RecommendationResponseDTO> results = recommendationService.getRecommendations("Malibu", null, null, 5);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Ocean Villa", results.get(0).getProperty().getName());
    }
}
