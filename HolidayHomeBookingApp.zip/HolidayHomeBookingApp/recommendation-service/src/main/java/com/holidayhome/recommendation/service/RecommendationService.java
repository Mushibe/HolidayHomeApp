package com.holidayhome.recommendation.service;

import com.holidayhome.recommendation.dto.RecommendationResponseDTO;

import java.util.List;

public interface RecommendationService {

    List<RecommendationResponseDTO> getRecommendations(String location, String amenity, String attraction, Integer limit);

    List<RecommendationResponseDTO> getUserPersonalizedRecommendations(Long userId, Integer limit);
}
