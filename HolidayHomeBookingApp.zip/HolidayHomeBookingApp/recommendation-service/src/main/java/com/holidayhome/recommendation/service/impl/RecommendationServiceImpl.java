package com.holidayhome.recommendation.service.impl;

import com.holidayhome.recommendation.client.PropertyClient;
import com.holidayhome.recommendation.client.UserClient;
import com.holidayhome.recommendation.dto.ApiResponse;
import com.holidayhome.recommendation.dto.PropertyDTO;
import com.holidayhome.recommendation.dto.RecommendationResponseDTO;
import com.holidayhome.recommendation.service.RecommendationService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RecommendationServiceImpl implements RecommendationService {

    private static final Logger log = LoggerFactory.getLogger(RecommendationServiceImpl.class);

    private final PropertyClient propertyClient;
    private final UserClient userClient;

    @Override
    public List<RecommendationResponseDTO> getRecommendations(String location, String amenity, String attraction, Integer limit) {
        log.info("Calculating recommendations for location: {}, amenity: {}, attraction: {}", location, amenity, attraction);

        ApiResponse<List<PropertyDTO>> response = propertyClient.getAllProperties();
        if (response == null || response.getData() == null) {
            return Collections.emptyList();
        }

        List<PropertyDTO> properties = response.getData();
        List<RecommendationResponseDTO> recommendations = new ArrayList<>();

        for (PropertyDTO prop : properties) {
            double score = 50.0; // Base score
            List<String> matchReasons = new ArrayList<>();

            // Location score weighting (30 pts)
            if (location != null && !location.isBlank() && prop.getLocation() != null &&
                prop.getLocation().toLowerCase().contains(location.toLowerCase())) {
                score += 30.0;
                matchReasons.add("Location matches '" + location + "'");
            }

            // Amenity score weighting (15 pts per match)
            if (amenity != null && !amenity.isBlank() && prop.getAmenities() != null) {
                boolean hasAmenity = prop.getAmenities().stream()
                        .anyMatch(a -> a.getAmenityName() != null && a.getAmenityName().toLowerCase().contains(amenity.toLowerCase()));
                if (hasAmenity) {
                    score += 15.0;
                    matchReasons.add("Features amenity '" + amenity + "'");
                }
            }

            // Attraction score weighting (15 pts per match)
            if (attraction != null && !attraction.isBlank() && prop.getAttractions() != null) {
                boolean hasAttraction = prop.getAttractions().stream()
                        .anyMatch(att -> att.getAttractionName() != null && att.getAttractionName().toLowerCase().contains(attraction.toLowerCase()));
                if (hasAttraction) {
                    score += 15.0;
                    matchReasons.add("Close to attraction '" + attraction + "'");
                }
            }

            if (matchReasons.isEmpty()) {
                matchReasons.add("Popular trending holiday home");
            }

            recommendations.add(RecommendationResponseDTO.builder()
                    .property(prop)
                    .recommendationScore(Math.min(score, 100.0))
                    .matchReason(String.join("; ", matchReasons))
                    .build());
        }

        recommendations.sort(Comparator.comparingDouble(RecommendationResponseDTO::getRecommendationScore).reversed());

        int maxLimit = (limit != null && limit > 0) ? limit : 10;
        return recommendations.stream().limit(maxLimit).toList();
    }

    @Override
    public List<RecommendationResponseDTO> getUserPersonalizedRecommendations(Long userId, Integer limit) {
        log.info("Generating personalized recommendations for user ID: {}", userId);
        try {
            userClient.getUserById(userId);
        } catch (Exception ex) {
            log.warn("Could not fetch user info for ID {}: {}", userId, ex.getMessage());
        }

        return getRecommendations(null, null, null, limit);
    }
}
