package com.holidayhome.recommendation.controller;

import com.holidayhome.recommendation.dto.ApiResponse;
import com.holidayhome.recommendation.dto.RecommendationResponseDTO;
import com.holidayhome.recommendation.service.RecommendationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/recommendations")
@RequiredArgsConstructor
@Tag(name = "Recommendation Controller", description = "Endpoints for recommending holiday homes based on user preferences, location, amenities, and attractions")
public class RecommendationController {

    private static final Logger log = LoggerFactory.getLogger(RecommendationController.class);

    private final RecommendationService recommendationService;

    @GetMapping
    @Operation(summary = "Get property recommendations", description = "Recommends holiday homes filtered by location, amenities, or tourist attractions")
    public ResponseEntity<ApiResponse<List<RecommendationResponseDTO>>> getRecommendations(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String amenity,
            @RequestParam(required = false) String attraction,
            @RequestParam(required = false, defaultValue = "10") Integer limit) {
        log.info("REST request for property recommendations");
        List<RecommendationResponseDTO> list = recommendationService.getRecommendations(location, amenity, attraction, limit);
        return ResponseEntity.ok(ApiResponse.success("Recommendations retrieved successfully", list));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get personalized user recommendations", description = "Personalized property recommendations tailored to user profile")
    public ResponseEntity<ApiResponse<List<RecommendationResponseDTO>>> getUserRecommendations(
            @PathVariable Long userId,
            @RequestParam(required = false, defaultValue = "5") Integer limit) {
        log.info("REST request for user personalized recommendations for ID: {}", userId);
        List<RecommendationResponseDTO> list = recommendationService.getUserPersonalizedRecommendations(userId, limit);
        return ResponseEntity.ok(ApiResponse.success("Personalized recommendations retrieved successfully", list));
    }
}
