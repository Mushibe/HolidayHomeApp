package com.holidayhome.recommendation.client;

import com.holidayhome.recommendation.dto.ApiResponse;
import com.holidayhome.recommendation.dto.PropertyDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "PROPERTY-SERVICE")
public interface PropertyClient {

    @GetMapping("/properties")
    ApiResponse<List<PropertyDTO>> getAllProperties();
}
