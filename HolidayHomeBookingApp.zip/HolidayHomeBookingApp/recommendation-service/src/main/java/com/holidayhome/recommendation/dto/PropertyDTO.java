package com.holidayhome.recommendation.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PropertyDTO {

    private Long id;
    private String name;
    private String description;
    private String location;
    private String address;
    private LocalDate availabilityFrom;
    private LocalDate availabilityTo;
    private String ownerName;
    private List<AmenityDTO> amenities;
    private List<AttractionDTO> attractions;
}
