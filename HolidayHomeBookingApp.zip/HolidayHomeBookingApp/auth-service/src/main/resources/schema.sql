-- Auth Database Schema Script

CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role VARCHAR(20) NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Seed Initial Users (Password: admin123 and user123 hashed with BCrypt)
INSERT INTO users (username, password, email, role, created_at)
VALUES 
('admin', '$2a$10$7Q77s6Xm7S7.g6V6U7Z5f.Qp4B4t0W9z8x7y6w5v4u3t2s1r0q', 'admin@holidayhome.com', 'ROLE_ADMIN', CURRENT_TIMESTAMP),
('john_doe', '$2a$10$7Q77s6Xm7S7.g6V6U7Z5f.Qp4B4t0W9z8x7y6w5v4u3t2s1r0q', 'john@example.com', 'ROLE_USER', CURRENT_TIMESTAMP)
ON CONFLICT (username) DO NOTHING;
