package com.holidayhome.auth.service;

import com.holidayhome.auth.dto.AuthRequestDTO;
import com.holidayhome.auth.dto.AuthResponseDTO;
import com.holidayhome.auth.dto.RefreshTokenRequestDTO;
import com.holidayhome.auth.dto.RegisterRequestDTO;

public interface AuthService {

    AuthResponseDTO register(RegisterRequestDTO requestDTO);

    AuthResponseDTO login(AuthRequestDTO requestDTO);

    AuthResponseDTO refreshToken(RefreshTokenRequestDTO requestDTO);
}
