package com.holidayhome.auth.service.impl;

import com.holidayhome.auth.dto.AuthRequestDTO;
import com.holidayhome.auth.dto.AuthResponseDTO;
import com.holidayhome.auth.dto.RefreshTokenRequestDTO;
import com.holidayhome.auth.dto.RegisterRequestDTO;
import com.holidayhome.auth.entity.UserEntity;
import com.holidayhome.auth.exception.DuplicateUserException;
import com.holidayhome.auth.exception.UnauthorizedAccessException;
import com.holidayhome.auth.exception.UserNotFoundException;
import com.holidayhome.auth.mapper.UserMapper;
import com.holidayhome.auth.repository.UserRepository;
import com.holidayhome.auth.security.JwtProvider;
import com.holidayhome.auth.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public AuthResponseDTO register(RegisterRequestDTO requestDTO) {
        log.info("Attempting registration for username: {}", requestDTO.getUsername());

        if (userRepository.existsByUsername(requestDTO.getUsername())) {
            throw new DuplicateUserException("Username '" + requestDTO.getUsername() + "' is already taken");
        }

        if (userRepository.existsByEmail(requestDTO.getEmail())) {
            throw new DuplicateUserException("Email '" + requestDTO.getEmail() + "' is already registered");
        }

        String encodedPassword = passwordEncoder.encode(requestDTO.getPassword());
        UserEntity userEntity = userMapper.toEntity(requestDTO, encodedPassword);

        UserEntity savedUser = userRepository.save(userEntity);
        log.info("User registered successfully with ID: {}", savedUser.getId());

        String token = jwtProvider.generateToken(savedUser.getUsername(), savedUser.getRole().name(), savedUser.getId());
        String refreshToken = jwtProvider.generateRefreshToken(savedUser.getUsername());

        return AuthResponseDTO.builder()
                .token(token)
                .refreshToken(refreshToken)
                .username(savedUser.getUsername())
                .email(savedUser.getEmail())
                .role(savedUser.getRole())
                .userId(savedUser.getId())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public AuthResponseDTO login(AuthRequestDTO requestDTO) {
        log.info("Login attempt for username: {}", requestDTO.getUsername());

        UserEntity user = userRepository.findByUsername(requestDTO.getUsername())
                .orElseThrow(() -> new UserNotFoundException("Invalid username or password"));

        if (!passwordEncoder.matches(requestDTO.getPassword(), user.getPassword())) {
            throw new UnauthorizedAccessException("Invalid username or password");
        }

        String token = jwtProvider.generateToken(user.getUsername(), user.getRole().name(), user.getId());
        String refreshToken = jwtProvider.generateRefreshToken(user.getUsername());

        log.info("Login successful for user: {}", user.getUsername());

        return AuthResponseDTO.builder()
                .token(token)
                .refreshToken(refreshToken)
                .username(user.getUsername())
                .email(user.getEmail())
                .role(user.getRole())
                .userId(user.getId())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public AuthResponseDTO refreshToken(RefreshTokenRequestDTO requestDTO) {
        String refreshToken = requestDTO.getRefreshToken();
        if (!jwtProvider.validateToken(refreshToken)) {
            throw new UnauthorizedAccessException("Invalid or expired refresh token");
        }

        String username = jwtProvider.getUsernameFromToken(refreshToken);
        UserEntity user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found for provided token"));

        String newAccessToken = jwtProvider.generateToken(user.getUsername(), user.getRole().name(), user.getId());
        String newRefreshToken = jwtProvider.generateRefreshToken(user.getUsername());

        return AuthResponseDTO.builder()
                .token(newAccessToken)
                .refreshToken(newRefreshToken)
                .username(user.getUsername())
                .email(user.getEmail())
                .role(user.getRole())
                .userId(user.getId())
                .build();
    }
}
