package com.holidayhome.auth.controller;

import com.holidayhome.auth.dto.ApiResponse;
import com.holidayhome.auth.dto.AuthRequestDTO;
import com.holidayhome.auth.dto.AuthResponseDTO;
import com.holidayhome.auth.dto.RefreshTokenRequestDTO;
import com.holidayhome.auth.dto.RegisterRequestDTO;
import com.holidayhome.auth.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication Controller", description = "Endpoints for user registration, authentication, and token management")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;

    @PostMapping("/register")
    @Operation(summary = "Register a new user or admin", description = "Creates a new user record and returns JWT tokens")
    public ResponseEntity<ApiResponse<AuthResponseDTO>> register(@Valid @RequestBody RegisterRequestDTO requestDTO) {
        log.info("REST request to register user: {}", requestDTO.getUsername());
        AuthResponseDTO response = authService.register(requestDTO);
        return new ResponseEntity<>(ApiResponse.success("User registered successfully", response), HttpStatus.CREATED);
    }

    @PostMapping("/login")
    @Operation(summary = "Authenticate user", description = "Validates user credentials and generates JWT access & refresh tokens")
    public ResponseEntity<ApiResponse<AuthResponseDTO>> login(@Valid @RequestBody AuthRequestDTO requestDTO) {
        log.info("REST request to login user: {}", requestDTO.getUsername());
        AuthResponseDTO response = authService.login(requestDTO);
        return ResponseEntity.ok(ApiResponse.success("User logged in successfully", response));
    }

    @PostMapping("/refresh")
    @Operation(summary = "Refresh JWT access token", description = "Generates a new access token using a valid refresh token")
    public ResponseEntity<ApiResponse<AuthResponseDTO>> refresh(@Valid @RequestBody RefreshTokenRequestDTO requestDTO) {
        log.info("REST request to refresh JWT token");
        AuthResponseDTO response = authService.refreshToken(requestDTO);
        return ResponseEntity.ok(ApiResponse.success("Token refreshed successfully", response));
    }
}
