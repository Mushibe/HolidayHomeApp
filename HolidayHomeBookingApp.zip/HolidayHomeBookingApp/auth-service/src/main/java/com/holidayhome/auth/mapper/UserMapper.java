package com.holidayhome.auth.mapper;

import com.holidayhome.auth.dto.RegisterRequestDTO;
import com.holidayhome.auth.entity.UserEntity;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public UserEntity toEntity(RegisterRequestDTO dto, String encodedPassword) {
        if (dto == null) {
            return null;
        }
        return UserEntity.builder()
                .username(dto.getUsername())
                .password(encodedPassword)
                .email(dto.getEmail())
                .role(dto.getRole())
                .build();
    }
}
