package com.holidayhome.auth.service;

import com.holidayhome.auth.dto.AuthRequestDTO;
import com.holidayhome.auth.dto.AuthResponseDTO;
import com.holidayhome.auth.dto.RegisterRequestDTO;
import com.holidayhome.auth.entity.Role;
import com.holidayhome.auth.entity.UserEntity;
import com.holidayhome.auth.exception.DuplicateUserException;
import com.holidayhome.auth.exception.UnauthorizedAccessException;
import com.holidayhome.auth.exception.UserNotFoundException;
import com.holidayhome.auth.mapper.UserMapper;
import com.holidayhome.auth.repository.UserRepository;
import com.holidayhome.auth.security.JwtProvider;
import com.holidayhome.auth.service.impl.AuthServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtProvider jwtProvider;

    @Mock
    private UserMapper userMapper;

    @InjectMocks
    private AuthServiceImpl authService;

    private UserEntity userEntity;
    private RegisterRequestDTO registerDTO;
    private AuthRequestDTO authDTO;

    @BeforeEach
    void setUp() {
        userEntity = UserEntity.builder()
                .id(1L)
                .username("testuser")
                .password("encoded_pass")
                .email("test@example.com")
                .role(Role.ROLE_USER)
                .build();

        registerDTO = RegisterRequestDTO.builder()
                .username("testuser")
                .password("raw_pass")
                .email("test@example.com")
                .role(Role.ROLE_USER)
                .build();

        authDTO = AuthRequestDTO.builder()
                .username("testuser")
                .password("raw_pass")
                .build();
    }

    @Test
    void register_Success() {
        when(userRepository.existsByUsername(anyString())).thenReturn(false);
        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encoded_pass");
        when(userMapper.toEntity(any(), anyString())).thenReturn(userEntity);
        when(userRepository.save(any())).thenReturn(userEntity);
        when(jwtProvider.generateToken(anyString(), anyString(), any())).thenReturn("access_token");
        when(jwtProvider.generateRefreshToken(anyString())).thenReturn("refresh_token");

        AuthResponseDTO response = authService.register(registerDTO);

        assertNotNull(response);
        assertEquals("testuser", response.getUsername());
        assertEquals("access_token", response.getToken());
    }

    @Test
    void register_DuplicateUsername_ThrowsException() {
        when(userRepository.existsByUsername("testuser")).thenReturn(true);

        assertThrows(DuplicateUserException.class, () -> authService.register(registerDTO));
    }

    @Test
    void login_Success() {
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(userEntity));
        when(passwordEncoder.matches("raw_pass", "encoded_pass")).thenReturn(true);
        when(jwtProvider.generateToken(anyString(), anyString(), any())).thenReturn("access_token");
        when(jwtProvider.generateRefreshToken(anyString())).thenReturn("refresh_token");

        AuthResponseDTO response = authService.login(authDTO);

        assertNotNull(response);
        assertEquals("testuser", response.getUsername());
    }

    @Test
    void login_UserNotFound_ThrowsException() {
        when(userRepository.findByUsername("unknown")).thenReturn(Optional.empty());
        authDTO.setUsername("unknown");

        assertThrows(UserNotFoundException.class, () -> authService.login(authDTO));
    }

    @Test
    void login_WrongPassword_ThrowsException() {
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(userEntity));
        when(passwordEncoder.matches("wrong_pass", "encoded_pass")).thenReturn(false);
        authDTO.setPassword("wrong_pass");

        assertThrows(UnauthorizedAccessException.class, () -> authService.login(authDTO));
    }
}
