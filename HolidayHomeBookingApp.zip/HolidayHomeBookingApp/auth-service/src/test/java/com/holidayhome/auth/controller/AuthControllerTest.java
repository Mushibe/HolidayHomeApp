package com.holidayhome.auth.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.holidayhome.auth.dto.AuthRequestDTO;
import com.holidayhome.auth.dto.AuthResponseDTO;
import com.holidayhome.auth.dto.RegisterRequestDTO;
import com.holidayhome.auth.entity.Role;
import com.holidayhome.auth.service.AuthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuthController.class)
@AutoConfigureMockMvc(addFilters = false)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void register_Success() throws Exception {
        RegisterRequestDTO dto = RegisterRequestDTO.builder()
                .username("john")
                .password("password123")
                .email("john@example.com")
                .role(Role.ROLE_USER)
                .build();

        AuthResponseDTO responseDTO = AuthResponseDTO.builder()
                .token("dummy-jwt-token")
                .username("john")
                .email("john@example.com")
                .role(Role.ROLE_USER)
                .userId(1L)
                .build();

        when(authService.register(any())).thenReturn(responseDTO);

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.username").value("john"));
    }

    @Test
    void login_Success() throws Exception {
        AuthRequestDTO dto = AuthRequestDTO.builder()
                .username("john")
                .password("password123")
                .build();

        AuthResponseDTO responseDTO = AuthResponseDTO.builder()
                .token("dummy-jwt-token")
                .username("john")
                .role(Role.ROLE_USER)
                .userId(1L)
                .build();

        when(authService.login(any())).thenReturn(responseDTO);

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.token").value("dummy-jwt-token"));
    }
}
