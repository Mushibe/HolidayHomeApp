# HOLIDAY HOME BOOKING APPLICATION
## Enterprise Microservices Platform Presentation (20 Slides)

---

### SLIDE 1: Title
- **Title**: Holiday Home Booking Application
- **Subtitle**: Enterprise Microservices Architecture for Property Exploration & Preference-Based Recommendation
- **Presenter**: Senior Solution Architect & Lead Microservices Developer
- **Technology Stack**: Java 21, Spring Boot 3.2, Spring Cloud 2023, PostgreSQL, Docker, Kubernetes, AWS

---

### SLIDE 2: Problem Statement
- Tourists and vacationers face fragmented platforms when searching for curated holiday homes and tourist spots.
- Existing platforms mix complex, unwanted booking/payment flows when users only wish to explore properties, amenities, and attractions.
- Monolithic platforms lack elastic scalability and personalized recommendation engines tailored to location and local attractions.

---

### SLIDE 3: Objectives
- Build an enterprise-grade property discovery & recommendation platform.
- Strictly separate user exploration from booking (explicitly zero booking overhead).
- Implement 100% decoupled microservice architecture (7 microservices).
- Deliver real-time preference matching based on location, amenities, dates, and tourist attractions.
- Ensure security, automated DevOps CI/CD, and high availability on AWS EC2 & Kubernetes.

---

### SLIDE 4: Existing System
- **Monolithic Architecture**: Single database and tightly coupled modules leading to single points of failure.
- **Limited Filtering**: Primitive keyword search missing multi-attribute scoring.
- **High Friction**: Mandatory registration and transaction prompts prior to viewing property media.
- **Poor Scalability**: Inability to independently scale high-traffic property search during peak holiday seasons.

---

### SLIDE 5: Proposed System
- **Microservices Architecture**: 7 resilient, independently deployable microservices.
- **Dedicated Discovery**: Eureka Discovery Server + Spring Cloud Gateway single entrypoint.
- **Intelligent Recommendation**: Weighted recommendation engine ranking properties based on multi-criteria metrics.
- **Rich Media & Amenity View**: 1:N relations for property photo galleries, amenities, and nearby tourist attractions with distance indicators.

---

### SLIDE 6: Architecture Diagram
- **API Gateway (8080)**: Centralized routing, CORS, and JWT filter.
- **Discovery (8761)**: Eureka service registry.
- **Service Mesh**: Auth (8081), Property (8082), User (8083), Feedback (8084), Recommendation (8085).
- **Inter-Service Communication**: OpenFeign + Spring Cloud LoadBalancer.
- **Databases**: Isolated PostgreSQL databases (`auth_db`, `property_db`, `user_db`, `feedback_db`).

---

### SLIDE 7: Microservices Overview
- **Auth Service (8081)**: User registration, login, JWT token generation, role management.
- **Property Service (8082)**: Listing creation, updates, amenities, photo galleries, tourist attractions.
- **User Service (8083)**: Detailed user profile management.
- **Feedback Service (8084)**: Ratings (1-5 stars) and user review comments.
- **Recommendation Service (8085)**: Multi-factor scoring recommendation engine.

---

### SLIDE 8: Database Design
- **Database per Service Pattern**: PostgreSQL 16.
- **`auth_db.users`**: Account credentials, hashed passwords, roles (`ROLE_ADMIN`, `ROLE_USER`).
- **`property_db.properties`**: Core property attributes with 1:N relations (`amenities`, `property_images`, `attractions`).
- **`user_db.user_profiles`**: User details, phone numbers, addresses.
- **`feedback_db.feedback`**: Ratings and comment records linked by foreign key IDs.

---

### SLIDE 9: Security Design
- **Spring Security 6 & OAuth2 / JWT**: Stateless session management.
- **Password Hashing**: BCryptPasswordEncoder with salt.
- **Role-Based Access Control (RBAC)**:
  - `ROLE_ADMIN`: Create, update, delete properties; view system users & feedback.
  - `ROLE_USER`: Search properties, view details/amenities, submit feedback.

---

### SLIDE 10: API Gateway
- Built with **Spring Cloud Gateway**.
- Functions on Port 8080.
- Implements custom `AuthenticationFilter` checking `Authorization: Bearer <token>`.
- Dynamically routes requests using Eureka service IDs (`lb://AUTH-SERVICE`, `lb://PROPERTY-SERVICE`, etc.).
- Eliminates CORS issues across front-end consumers.

---

### SLIDE 11: JWT Flow
1. Client calls `POST /auth/login` with credentials.
2. Auth Service validates credentials against BCrypt hash in `auth_db`.
3. Auth Service issues signed HMAC-SHA256 JWT access token (24h) and refresh token (7d).
4. Client passes `Bearer <token>` in HTTP Authorization header for subsequent API calls.
5. API Gateway verifies signature & claims before forwarding requests.

---

### SLIDE 12: Exception Handling
- Centralized exception management using Spring `@RestControllerAdvice`.
- Custom Domain Exceptions:
  - `PropertyNotFoundException` (404)
  - `UserNotFoundException` (404)
  - `DuplicateUserException` (409)
  - `FeedbackNotFoundException` (404)
  - `UnauthorizedAccessException` (401)
- Standardized error format: `{ timestamp, status, error, message, path }`.

---

### SLIDE 13: Swagger / OpenAPI
- Integrated **Springdoc OpenAPI 3 UI** across all microservices.
- Accessible at `/swagger-ui.html` per service.
- Provides interactive REST execution, request/response schema modeling, and OAuth2 security authorization testing.

---

### SLIDE 14: Testing Strategy
- **JUnit 5 & Mockito**: Complete unit testing for Services, Controllers, and Repositories.
- **MockMvc**: Web layer integration testing with simulated requests.
- **Target Code Coverage**: Minimum 85% verified via JaCoCo.
- Isolated in-memory H2 database testing profiles.

---

### SLIDE 15: DevOps Pipeline
- **Automated Jenkins Pipeline (`Jenkinsfile`)**:
  1. Git checkout & GitFlow branching strategy.
  2. Code Quality checks using PMD, Checkstyle, and SpotBugs.
  3. Automated JUnit test execution.
  4. SonarQube static code analysis.
  5. Docker container image build & registry push.
  6. Automated Kubernetes deployment rollout.

---

### SLIDE 16: Docker & Kubernetes
- **Docker**:
  - Alpine-based lightweight container image per microservice.
  - `docker-compose.yml` for single-command local orchestration.
- **Kubernetes**:
  - Modular manifests (`k8s/*.yaml`).
  - Deployments, ClusterIP Services, ConfigMaps, Secrets, Ingress Controller.
  - Horizontal Pod Autoscaler (HPA) targeting 70% CPU threshold.

---

### SLIDE 17: AWS EC2 Deployment
- Production deployment on AWS EC2 Ubuntu LTS instance.
- Docker Engine & Docker Compose automated initialization.
- Security Groups configured for Port 8080 (API Gateway) and SSL/TLS termination.
- Zero-downtime container updates and live SLF4J logging to disk (`logs/application.log`).

---

### SLIDE 18: Advantages
- **Targeted User Experience**: Fast property discovery without booking clutter.
- **Elastic Scalability**: Independent scaling of high-demand microservices.
- **High Security**: Stateless JWT authentication with strict RBAC.
- **Production-Ready DevOps**: Full CI/CD pipeline, containerization, and K8s orchestration.

---

### SLIDE 19: Future Enhancements
- Artificial Intelligence / Machine Learning preference learning for recommendation engine.
- 360-degree Virtual Property Tours and VR integration.
- Multi-language and currency dynamic localization.
- Mobile push notifications for newly added holiday homes in saved favorite locations.

---

### SLIDE 20: Thank You
- **Holiday Home Booking Application**
- Enterprise Backend Microservices Platform
- Questions & Discussion
