# REST API SPECIFICATION DOCUMENT
**Project Name**: Holiday Home Booking Application  
**Base URL**: `http://localhost:8080` (API Gateway)  

---

## 1. Authentication Service Endpoints (`/auth`)

### 1.1 `POST /auth/register`
- **Description**: Registers a new user or admin.
- **Request Body**:
  ```json
  {
    "username": "john_doe",
    "password": "password123",
    "email": "john@example.com",
    "role": "ROLE_USER"
  }
  ```
- **Response** (`201 CREATED`):
  ```json
  {
    "success": true,
    "message": "User registered successfully",
    "data": {
      "token": "eyJhbGciOiJIUzI1NiJ9...",
      "refreshToken": "eyJhbGciOiJIUzI1NiJ9...",
      "username": "john_doe",
      "email": "john@example.com",
      "role": "ROLE_USER",
      "userId": 1
    },
    "timestamp": "2026-09-28T00:00:00"
  }
  ```

### 1.2 `POST /auth/login`
- **Request Body**:
  ```json
  {
    "username": "john_doe",
    "password": "password123"
  }
  ```
- **Response** (`200 OK`): Token and user details envelope.

---

## 2. Property Service Endpoints (`/properties`)

### 2.1 `POST /properties` (Admin)
- **Header**: `Authorization: Bearer <token>`
- **Request Body**:
  ```json
  {
    "name": "Sunset Ocean Villa",
    "description": "Luxury beachfront villa",
    "location": "Malibu",
    "address": "789 Ocean Highway",
    "availabilityFrom": "2026-01-01",
    "availabilityTo": "2026-12-31",
    "ownerName": "Robert Vance",
    "amenities": [{"amenityName": "Private Swimming Pool"}],
    "images": [{"imageUrl": "https://images.unsplash.com/photo-1512917774080"}],
    "attractions": [{"attractionName": "Zuma Beach", "distance": "1.5 km"}]
  }
  ```

### 2.2 `GET /properties` (Public)
- **Response**: List of all holiday home properties.

### 2.3 `GET /properties/search`
- **Parameters**: `location`, `fromDate`, `toDate`
- **Response**: Matching properties.

---

## 3. Feedback Service Endpoints (`/feedback`)

### 3.1 `POST /feedback` (User)
- **Request Body**:
  ```json
  {
    "propertyId": 1,
    "userId": 1,
    "rating": 5,
    "comments": "Stunning location and great pool!"
  }
  ```

### 3.2 `GET /feedback/property/{propertyId}`
- **Response**: Review list for specified property.

---

## 4. Recommendation Service Endpoints (`/recommendations`)

### 4.1 `GET /recommendations`
- **Parameters**: `location`, `amenity`, `attraction`, `limit`
- **Response**: Ranked properties with match reasoning and score (0-100%).
