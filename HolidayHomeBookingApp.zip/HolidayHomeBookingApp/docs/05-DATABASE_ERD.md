# DATABASE ER DIAGRAM & SCHEMA SPECIFICATION
**Project Name**: Holiday Home Booking Application  

---

## 1. Database Entity-Relationship Diagram

```mermaid
erDiagram
    %% Auth Database
    USERS {
        bigint id PK
        string username UK
        string password
        string email UK
        string role
        timestamp created_at
    }

    %% User Database
    USER_PROFILES {
        bigint id PK
        string username UK
        string email UK
        string full_name
        string phone_number
        string address
        timestamp created_at
        timestamp updated_at
    }

    %% Property Database
    PROPERTIES ||--o{ AMENITIES : "has"
    PROPERTIES ||--o{ PROPERTY_IMAGES : "has"
    PROPERTIES ||--o{ ATTRACTIONS : "has"

    PROPERTIES {
        bigint id PK
        string name
        text description
        string location
        string address
        date availability_from
        date availability_to
        string owner_name
        timestamp created_at
        timestamp updated_at
    }

    AMENITIES {
        bigint id PK
        bigint property_id FK
        string amenity_name
    }

    PROPERTY_IMAGES {
        bigint id PK
        bigint property_id FK
        string image_url
    }

    ATTRACTIONS {
        bigint id PK
        bigint property_id FK
        string attraction_name
        string distance
    }

    %% Feedback Database
    FEEDBACK {
        bigint id PK
        bigint property_id
        bigint user_id
        int rating
        text comments
        timestamp created_at
    }
```

---

## 2. Table Schemas Summary

### 2.1 `auth_db.users`
- `id` (PK, BIGSERIAL)
- `username` (VARCHAR 50, UNIQUE, NOT NULL)
- `password` (VARCHAR 255, NOT NULL)
- `email` (VARCHAR 100, UNIQUE, NOT NULL)
- `role` (VARCHAR 20, NOT NULL) -- `ROLE_ADMIN`, `ROLE_USER`
- `created_at` (TIMESTAMP)

### 2.2 `property_db.properties`
- `id` (PK, BIGSERIAL)
- `name` (VARCHAR 150, NOT NULL)
- `description` (TEXT)
- `location` (VARCHAR 100, NOT NULL)
- `address` (VARCHAR 255, NOT NULL)
- `availability_from` (DATE)
- `availability_to` (DATE)
- `owner_name` (VARCHAR 100, NOT NULL)
- `created_at` (TIMESTAMP), `updated_at` (TIMESTAMP)

### 2.3 `property_db.amenities` (1:N)
- `id` (PK, BIGSERIAL)
- `property_id` (FK -> properties.id)
- `amenity_name` (VARCHAR 100, NOT NULL)

### 2.4 `property_db.property_images` (1:N)
- `id` (PK, BIGSERIAL)
- `property_id` (FK -> properties.id)
- `image_url` (VARCHAR 500, NOT NULL)

### 2.5 `property_db.attractions` (1:N)
- `id` (PK, BIGSERIAL)
- `property_id` (FK -> properties.id)
- `attraction_name` (VARCHAR 150, NOT NULL)
- `distance` (VARCHAR 50, NOT NULL)

### 2.6 `feedback_db.feedback`
- `id` (PK, BIGSERIAL)
- `property_id` (BIGINT, NOT NULL)
- `user_id` (BIGINT, NOT NULL)
- `rating` (INT 1-5, NOT NULL)
- `comments` (TEXT)
- `created_at` (TIMESTAMP)
