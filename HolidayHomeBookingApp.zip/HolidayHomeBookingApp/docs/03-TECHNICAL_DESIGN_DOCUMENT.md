# TECHNICAL DESIGN DOCUMENT (TDD)
**Project Name**: Holiday Home Booking Application  
**Version**: 1.0.0 Enterprise  

---

## 1. Architecture Strategy & Principles

The system adopts a **Cloud-Native Microservices Architecture** adhering to enterprise patterns:

1. **Microservices Architecture Pattern**: Independent, decoupled services owning their respective PostgreSQL databases.
2. **API Gateway Pattern**: Single entrypoint utilizing Spring Cloud Gateway for JWT verification and downstream routing.
3. **Service Discovery Pattern**: Netflix Eureka Discovery Server for dynamic instance registration and client-side load balancing.
4. **Inter-Service Communication**: Declarative HTTP REST via Spring Cloud OpenFeign.
5. **Clean & Layered Architecture**:
   - Controller Layer
   - Service Layer
   - Repository Layer
   - Entity Layer
   - DTO Layer
   - Mapper Layer
   - Exception Layer
   - Security Layer
   - Utility Layer
   - Config Layer

---

## 2. Microservices Breakdown

| Microservice Name | Port | Database | Primary Responsibilities |
|---|---|---|---|
| **Eureka Server** | 8761 | N/A | Central service discovery registry |
| **API Gateway** | 8080 | N/A | Dynamic routing, CORS, JWT gateway filter |
| **Auth Service** | 8081 | `auth_db` | User registration, login, JWT issuance, roles |
| **Property Service** | 8082 | `property_db` | Properties, amenities, images, attractions |
| **User Service** | 8083 | `user_db` | User profile details and management |
| **Feedback Service** | 8084 | `feedback_db` | Property ratings and reviews |
| **Recommendation Service** | 8085 | N/A | Algorithmic property ranking engine |

---

## 3. Layered Design Pattern

```
+-------------------------------------------------------+
|                   Controller Layer                    |
+-------------------------------------------------------+
                           |
                           v
+-------------------------------------------------------+
|                    Service Layer                      |
+-------------------------------------------------------+
             |                           |
             v                           v
+--------------------------+  +--------------------------+
|     Repository Layer     |  |     Feign Client Layer   |
+--------------------------+  +--------------------------+
             |                           |
             v                           v
+--------------------------+  +--------------------------+
|    Database (Postgres)   |  |   Remote Microservices   |
+--------------------------+  +--------------------------+
```

---

## 4. Exception Handling Strategy

Unified exception management via `@RestControllerAdvice`:
- **`PropertyNotFoundException`**: 404 NOT_FOUND
- **`UserNotFoundException`**: 404 NOT_FOUND
- **`DuplicateUserException`**: 409 CONFLICT
- **`FeedbackNotFoundException`**: 404 NOT_FOUND
- **`UnauthorizedAccessException`**: 401 UNAUTHORIZED
- Standardized Error Envelope (`ErrorResponse` containing `timestamp`, `status`, `error`, `message`, `path`).
