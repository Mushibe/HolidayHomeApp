# FUNCTIONAL SPECIFICATION DOCUMENT (FSD)
**Project Name**: Holiday Home Booking Application  
**Version**: 1.0.0 Enterprise  

---

## 1. Functional Scope Overview

The system features two primary operational modules: **Admin Module** and **User Module**.

```mermaid
graph TD
    User([User / Traveler]) --> AuthMod[Auth Service]
    Admin([Property Admin]) --> AuthMod
    
    subgraph Admin Functions
        AuthMod -->|ROLE_ADMIN| AddProp[Add / Update / Delete Property]
        AuthMod -->|ROLE_ADMIN| ViewUsers[View Users & Feedback]
    end

    subgraph User Functions
        AuthMod -->|ROLE_USER| SearchProp[Search & Explore Properties]
        AuthMod -->|ROLE_USER| RecEngine[Get Recommendations]
        AuthMod -->|ROLE_USER| SubmitFB[Submit Feedback & Rating]
    end
```

---

## 2. Admin Module Detailed Specifications

### 2.1 Admin Authentication
- Admin logs in via `/auth/login` with credentials.
- Receives JWT containing claim `"role": "ROLE_ADMIN"`.

### 2.2 Property Management
- **Endpoint**: `POST /properties`, `PUT /properties/{id}`, `DELETE /properties/{id}`
- Admin populates property details:
  - `name`, `description`, `location`, `address`
  - `availabilityFrom`, `availabilityTo`
  - `ownerName`
  - Associated `amenities` (1:N)
  - Associated `images` (1:N)
  - Associated `attractions` (1:N)

### 2.3 User & Feedback Oversight
- Admin views all registered profiles via `GET /users`.
- Admin reviews all submitted customer feedback via `GET /feedback`.

---

## 3. User Module Detailed Specifications

### 3.1 User Registration & Login
- User registers via `POST /auth/register`.
- Secure password hashing using BCrypt.
- Account default role set to `ROLE_USER`.

### 3.2 Property Exploration & Search
- Users search properties via `GET /properties/search?location=...&fromDate=...&toDate=...`.
- Displays property amenities, distance to tourist spots, and image galleries.

### 3.3 Recommendation Subsystem
- Request to `GET /recommendations?location=...&amenity=...&attraction=...`.
- Engine calculates matching scores (0 - 100%) and returns ranked properties.

### 3.4 Feedback Submission
- Users submit reviews via `POST /feedback` with a rating from 1 to 5 stars and comments.
