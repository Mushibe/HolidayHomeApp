# TEST STRATEGY & COVERAGE REPORT
**Project Name**: Holiday Home Booking Application  

---

## 1. Quality Assurance Objectives

The test strategy ensures **minimum 85% code coverage** across all microservices utilizing:
- **JUnit 5**: Standard unit test runner and assertion library.
- **Mockito**: Mocking dependencies for isolated unit tests.
- **MockMvc**: Spring Web MVC controller request/response verification.
- **H2 Database**: In-memory data repository validation.

---

## 2. Testing Layers Breakdown

### 2.1 Controller Tests (`*ControllerTest.java`)
- Validates HTTP status codes (`200 OK`, `201 CREATED`, `400 BAD_REQUEST`, `404 NOT_FOUND`, `401 UNAUTHORIZED`).
- Verifies JSON response payload structure and field mappings.
- Validates Jakarta Validation constraints (`@NotBlank`, `@Email`, `@Size`, `@Min`, `@Max`).

### 2.2 Service Unit Tests (`*ServiceTest.java`)
- Verifies business logic, scoring algorithms, and entity state mutations.
- Mocks repository and Feign client behavior.
- Asserts custom exception handling (`UserNotFoundException`, `DuplicateUserException`, etc.).

### 2.3 Repository Tests (`*RepositoryTest.java`)
- Tests JPA custom queries, custom finders, and database transaction isolation.

### 2.4 Global Exception Tests
- Ensures unhandled and custom runtime exceptions produce standard `ErrorResponse` JSON.

---

## 3. Execution Command

Run test suite across all 7 microservices:
```bash
mvn test
```
To generate Jacoco code coverage report:
```bash
mvn jacoco:report
```
