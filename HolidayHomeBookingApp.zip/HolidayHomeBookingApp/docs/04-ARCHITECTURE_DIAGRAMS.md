# ARCHITECTURE DIAGRAMS
**Project Name**: Holiday Home Booking Application  

---

## 1. System Architecture Diagram

```mermaid
flowchart TB
    subgraph Clients["Client Layer"]
        Browser["Web Browser"]
        Mobile["Mobile App"]
    end

    subgraph GatewayLayer["API Gateway Layer (Port 8080)"]
        Gateway["Spring Cloud Gateway\n(JWT Filter / Route Management)"]
    end

    subgraph DiscoveryLayer["Service Discovery"]
        Eureka["Eureka Discovery Server\n(Port 8761)"]
    end

    subgraph Microservices["Microservice Cluster"]
        AuthSvc["Auth Service\n(Port 8081)"]
        PropertySvc["Property Service\n(Port 8082)"]
        UserSvc["User Service\n(Port 8083)"]
        FeedbackSvc["Feedback Service\n(Port 8084)"]
        RecSvc["Recommendation Service\n(Port 8085)"]
    end

    subgraph Databases["PostgreSQL Databases"]
        AuthDB[("auth_db")]
        PropertyDB[("property_db")]
        UserDB[("user_db")]
        FeedbackDB[("feedback_db")]
    end

    Browser --> Gateway
    Mobile --> Gateway

    Gateway <--> Eureka
    AuthSvc <--> Eureka
    PropertySvc <--> Eureka
    UserSvc <--> Eureka
    FeedbackSvc <--> Eureka
    RecSvc <--> Eureka

    Gateway --> AuthSvc
    Gateway --> PropertySvc
    Gateway --> UserSvc
    Gateway --> FeedbackSvc
    Gateway --> RecSvc

    AuthSvc --> AuthDB
    PropertySvc --> PropertyDB
    UserSvc --> UserDB
    FeedbackSvc --> FeedbackDB

    FeedbackSvc -- OpenFeign --> UserSvc
    FeedbackSvc -- OpenFeign --> PropertySvc
    RecSvc -- OpenFeign --> PropertySvc
    RecSvc -- OpenFeign --> UserSvc
```

---

## 2. JWT Authentication Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    actor Client
    participant Gateway as API Gateway
    participant Auth as Auth Service
    participant Service as Property / User Service

    Client->>Gateway: POST /auth/login (username, password)
    Gateway->>Auth: Forward to Auth Service (Port 8081)
    Auth->>Auth: Validate Credentials & BCrypt Hash
    Auth-->>Client: Return JWT Access & Refresh Token

    Client->>Gateway: GET /properties (Header: Authorization Bearer <token>)
    Gateway->>Gateway: Validate JWT Signature & Expiry
    Gateway->>Service: Forward request with X-Auth-Username & X-Auth-Role
    Service-->>Gateway: Return 200 OK + ApiResponse<T>
    Gateway-->>Client: Return JSON Data
```
