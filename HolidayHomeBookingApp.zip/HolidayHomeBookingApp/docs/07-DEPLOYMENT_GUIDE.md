# DEPLOYMENT DOCUMENTATION & GUIDE
**Project Name**: Holiday Home Booking Application  

---

## 1. Environment Prerequisites

- **Java JDK**: 21 (LTS)
- **Maven**: 3.9+
- **Docker**: Engine 24.0+ & Docker Compose 2.20+
- **Kubernetes**: Cluster v1.28+ (`kubectl`, `helm`, or `minikube`)
- **AWS CLI**: Configured with EC2 / EKS credentials

---

## 2. Local Docker Compose Deployment

1. Build all Maven microservice JAR artifacts:
   ```bash
   mvn clean package -DskipTests
   ```

2. Start the Docker environment (PostgreSQL + Eureka + Gateway + 5 Microservices):
   ```bash
   docker-compose up --build -d
   ```

3. Verify running containers:
   ```bash
   docker-compose ps
   ```

4. Service URLs:
   - **API Gateway**: `http://localhost:8080`
   - **Eureka Dashboard**: `http://localhost:8761`
   - **Swagger UI (Auth Service)**: `http://localhost:8081/swagger-ui.html`
   - **Swagger UI (Property Service)**: `http://localhost:8082/swagger-ui.html`

---

## 3. Kubernetes Deployment (Production Cluster)

1. Create Namespace, Secret, and ConfigMap:
   ```bash
   kubectl apply -f k8s/01-namespace-secret-config.yaml
   ```

2. Deploy Database & Eureka Server:
   ```bash
   kubectl apply -f k8s/02-postgres.yaml
   kubectl apply -f k8s/03-eureka.yaml
   ```

3. Deploy Microservices Cluster:
   ```bash
   kubectl apply -f k8s/04-auth-service.yaml
   kubectl apply -f k8s/05-user-service.yaml
   kubectl apply -f k8s/06-property-service.yaml
   kubectl apply -f k8s/07-feedback-service.yaml
   kubectl apply -f k8s/08-recommendation-service.yaml
   kubectl apply -f k8s/09-api-gateway.yaml
   kubectl apply -f k8s/10-ingress-hpa.yaml
   ```

4. Check rollout status:
   ```bash
   kubectl get pods -n holiday-home
   ```

---

## 4. AWS EC2 Production Deployment Step-by-Step

1. Launch AWS EC2 Ubuntu 22.04 LTS instance (t3.large recommended).
2. SSH into instance and execute installation script:
   ```bash
   sudo apt-get update
   sudo apt-get install -y docker.io docker-compose git
   sudo systemctl enable docker
   sudo systemctl start docker
   ```
3. Clone repository and run Docker Compose:
   ```bash
   git clone https://github.com/company/holiday-home-booking-app.git
   cd holiday-home-booking-app
   docker-compose up -d --build
   ```
4. Configure EC2 Security Group inbound rules:
   - Allow Port 8080 (API Gateway / Public API)
   - Allow Port 8761 (Eureka Dashboard - Restricted IP)
