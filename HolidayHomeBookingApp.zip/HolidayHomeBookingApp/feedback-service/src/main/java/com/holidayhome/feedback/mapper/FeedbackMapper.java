package com.holidayhome.feedback.mapper;

import com.holidayhome.feedback.dto.FeedbackRequestDTO;
import com.holidayhome.feedback.dto.FeedbackResponseDTO;
import com.holidayhome.feedback.entity.FeedbackEntity;
import org.springframework.stereotype.Component;

@Component
public class FeedbackMapper {

    public FeedbackEntity toEntity(FeedbackRequestDTO dto) {
        if (dto == null) {
            return null;
        }
        return FeedbackEntity.builder()
                .propertyId(dto.getPropertyId())
                .userId(dto.getUserId())
                .rating(dto.getRating())
                .comments(dto.getComments())
                .build();
    }

    public FeedbackResponseDTO toDTO(FeedbackEntity entity) {
        if (entity == null) {
            return null;
        }
        return FeedbackResponseDTO.builder()
                .id(entity.getId())
                .propertyId(entity.getPropertyId())
                .userId(entity.getUserId())
                .rating(entity.getRating())
                .comments(entity.getComments())
                .createdAt(entity.getCreatedAt())
                .build();
    }
}
