package com.holidayhome.feedback.client;

import com.holidayhome.feedback.dto.ApiResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

@FeignClient(name = "PROPERTY-SERVICE")
public interface PropertyServiceClient {

    @GetMapping("/properties/{id}")
    ApiResponse<Map<String, Object>> getPropertyById(@PathVariable("id") Long id);
}
