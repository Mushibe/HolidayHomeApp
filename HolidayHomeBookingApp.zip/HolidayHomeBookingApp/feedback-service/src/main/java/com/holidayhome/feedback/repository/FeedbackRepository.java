package com.holidayhome.feedback.repository;

import com.holidayhome.feedback.entity.FeedbackEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<FeedbackEntity, Long> {

    List<FeedbackEntity> findByPropertyId(Long propertyId);

    List<FeedbackEntity> findByUserId(Long userId);
}
