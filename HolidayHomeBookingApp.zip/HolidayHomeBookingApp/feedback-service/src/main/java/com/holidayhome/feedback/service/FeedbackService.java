package com.holidayhome.feedback.service;

import com.holidayhome.feedback.dto.FeedbackRequestDTO;
import com.holidayhome.feedback.dto.FeedbackResponseDTO;

import java.util.List;

public interface FeedbackService {

    FeedbackResponseDTO addFeedback(FeedbackRequestDTO requestDTO);

    List<FeedbackResponseDTO> getAllFeedback();

    List<FeedbackResponseDTO> getFeedbackByPropertyId(Long propertyId);

    void deleteFeedback(Long id);
}
