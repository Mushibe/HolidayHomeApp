package com.holidayhome.feedback.controller;

import com.holidayhome.feedback.dto.ApiResponse;
import com.holidayhome.feedback.dto.FeedbackRequestDTO;
import com.holidayhome.feedback.dto.FeedbackResponseDTO;
import com.holidayhome.feedback.service.FeedbackService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/feedback")
@RequiredArgsConstructor
@Tag(name = "Feedback Controller", description = "Endpoints for submitting and viewing user feedback & property reviews")
public class FeedbackController {

    private static final Logger log = LoggerFactory.getLogger(FeedbackController.class);

    private final FeedbackService feedbackService;

    @PostMapping
    @Operation(summary = "Submit feedback", description = "User endpoint to submit rating and reviews for a property")
    public ResponseEntity<ApiResponse<FeedbackResponseDTO>> addFeedback(@Valid @RequestBody FeedbackRequestDTO requestDTO) {
        log.info("REST request to add feedback for property ID: {}", requestDTO.getPropertyId());
        FeedbackResponseDTO created = feedbackService.addFeedback(requestDTO);
        return new ResponseEntity<>(ApiResponse.success("Feedback submitted successfully", created), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all feedback", description = "Admin/User endpoint to view all submitted feedback")
    public ResponseEntity<ApiResponse<List<FeedbackResponseDTO>>> getAllFeedback() {
        log.info("REST request to fetch all feedback");
        List<FeedbackResponseDTO> feedbackList = feedbackService.getAllFeedback();
        return ResponseEntity.ok(ApiResponse.success("Feedback list retrieved successfully", feedbackList));
    }

    @GetMapping("/property/{propertyId}")
    @Operation(summary = "Get feedback by property ID", description = "View reviews and ratings for a specific holiday home property")
    public ResponseEntity<ApiResponse<List<FeedbackResponseDTO>>> getFeedbackByPropertyId(@PathVariable Long propertyId) {
        log.info("REST request to fetch feedback for property ID: {}", propertyId);
        List<FeedbackResponseDTO> feedbackList = feedbackService.getFeedbackByPropertyId(propertyId);
        return ResponseEntity.ok(ApiResponse.success("Property feedback retrieved successfully", feedbackList));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete feedback", description = "Admin endpoint to delete inappropriate feedback entries")
    public ResponseEntity<ApiResponse<Void>> deleteFeedback(@PathVariable Long id) {
        log.info("REST request to delete feedback ID: {}", id);
        feedbackService.deleteFeedback(id);
        return ResponseEntity.ok(ApiResponse.success("Feedback deleted successfully", null));
    }
}
