package com.holidayhome.feedback.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackResponseDTO {

    private Long id;
    private Long propertyId;
    private Long userId;
    private Integer rating;
    private String comments;
    private LocalDateTime createdAt;
}
