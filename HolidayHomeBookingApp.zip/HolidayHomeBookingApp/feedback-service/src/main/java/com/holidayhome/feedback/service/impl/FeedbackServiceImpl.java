package com.holidayhome.feedback.service.impl;

import com.holidayhome.feedback.client.PropertyServiceClient;
import com.holidayhome.feedback.client.UserServiceClient;
import com.holidayhome.feedback.dto.FeedbackRequestDTO;
import com.holidayhome.feedback.dto.FeedbackResponseDTO;
import com.holidayhome.feedback.entity.FeedbackEntity;
import com.holidayhome.feedback.exception.FeedbackNotFoundException;
import com.holidayhome.feedback.mapper.FeedbackMapper;
import com.holidayhome.feedback.repository.FeedbackRepository;
import com.holidayhome.feedback.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FeedbackServiceImpl implements FeedbackService {

    private static final Logger log = LoggerFactory.getLogger(FeedbackServiceImpl.class);

    private final FeedbackRepository feedbackRepository;
    private final FeedbackMapper feedbackMapper;
    private final UserServiceClient userServiceClient;
    private final PropertyServiceClient propertyServiceClient;

    @Override
    @Transactional
    public FeedbackResponseDTO addFeedback(FeedbackRequestDTO requestDTO) {
        log.info("Adding feedback for propertyId: {} by userId: {}", requestDTO.getPropertyId(), requestDTO.getUserId());

        // Validate property and user existence via Feign Clients safely with fallback handling
        try {
            propertyServiceClient.getPropertyById(requestDTO.getPropertyId());
        } catch (Exception ex) {
            log.warn("Could not verify property ID {} via PropertyServiceClient: {}", requestDTO.getPropertyId(), ex.getMessage());
        }

        try {
            userServiceClient.getUserById(requestDTO.getUserId());
        } catch (Exception ex) {
            log.warn("Could not verify user ID {} via UserServiceClient: {}", requestDTO.getUserId(), ex.getMessage());
        }

        FeedbackEntity entity = feedbackMapper.toEntity(requestDTO);
        FeedbackEntity saved = feedbackRepository.save(entity);
        log.info("Feedback saved with ID: {}", saved.getId());

        return feedbackMapper.toDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FeedbackResponseDTO> getAllFeedback() {
        log.info("Fetching all feedback entries");
        return feedbackRepository.findAll().stream()
                .map(feedbackMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<FeedbackResponseDTO> getFeedbackByPropertyId(Long propertyId) {
        log.info("Fetching feedback for property ID: {}", propertyId);
        return feedbackRepository.findByPropertyId(propertyId).stream()
                .map(feedbackMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void deleteFeedback(Long id) {
        log.info("Deleting feedback ID: {}", id);
        if (!feedbackRepository.existsById(id)) {
            throw new FeedbackNotFoundException("Feedback not found with ID: " + id);
        }
        feedbackRepository.deleteById(id);
        log.info("Feedback ID {} deleted successfully", id);
    }
}
