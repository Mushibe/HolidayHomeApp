-- Feedback Database Schema Script

CREATE TABLE IF NOT EXISTS feedback (
    id BIGSERIAL PRIMARY KEY,
    property_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comments TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Sample Data Seeding
INSERT INTO feedback (property_id, user_id, rating, comments, created_at)
VALUES 
(1, 1, 5, 'Breathtaking view of Malibu ocean! The pool was spotless and location was ultra convenient.', CURRENT_TIMESTAMP),
(2, 2, 4, 'Very cozy fireplace and hot tub. Great access to Aspen ski slopes.', CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;
