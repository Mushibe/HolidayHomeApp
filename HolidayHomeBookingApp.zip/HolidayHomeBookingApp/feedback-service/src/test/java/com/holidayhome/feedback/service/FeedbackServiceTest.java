package com.holidayhome.feedback.service;

import com.holidayhome.feedback.client.PropertyServiceClient;
import com.holidayhome.feedback.client.UserServiceClient;
import com.holidayhome.feedback.dto.FeedbackRequestDTO;
import com.holidayhome.feedback.dto.FeedbackResponseDTO;
import com.holidayhome.feedback.entity.FeedbackEntity;
import com.holidayhome.feedback.exception.FeedbackNotFoundException;
import com.holidayhome.feedback.mapper.FeedbackMapper;
import com.holidayhome.feedback.repository.FeedbackRepository;
import com.holidayhome.feedback.service.impl.FeedbackServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FeedbackServiceTest {

    @Mock
    private FeedbackRepository feedbackRepository;

    @Mock
    private FeedbackMapper feedbackMapper;

    @Mock
    private UserServiceClient userServiceClient;

    @Mock
    private PropertyServiceClient propertyServiceClient;

    @InjectMocks
    private FeedbackServiceImpl feedbackService;

    private FeedbackEntity feedbackEntity;
    private FeedbackRequestDTO requestDTO;
    private FeedbackResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        feedbackEntity = FeedbackEntity.builder()
                .id(1L)
                .propertyId(10L)
                .userId(5L)
                .rating(5)
                .comments("Outstanding property!")
                .build();

        requestDTO = FeedbackRequestDTO.builder()
                .propertyId(10L)
                .userId(5L)
                .rating(5)
                .comments("Outstanding property!")
                .build();

        responseDTO = FeedbackResponseDTO.builder()
                .id(1L)
                .propertyId(10L)
                .userId(5L)
                .rating(5)
                .comments("Outstanding property!")
                .build();
    }

    @Test
    void addFeedback_Success() {
        when(feedbackMapper.toEntity(any())).thenReturn(feedbackEntity);
        when(feedbackRepository.save(any())).thenReturn(feedbackEntity);
        when(feedbackMapper.toDTO(any())).thenReturn(responseDTO);

        FeedbackResponseDTO result = feedbackService.addFeedback(requestDTO);

        assertNotNull(result);
        assertEquals(5, result.getRating());
    }

    @Test
    void getFeedbackByPropertyId_Success() {
        when(feedbackRepository.findByPropertyId(10L)).thenReturn(List.of(feedbackEntity));
        when(feedbackMapper.toDTO(feedbackEntity)).thenReturn(responseDTO);

        List<FeedbackResponseDTO> results = feedbackService.getFeedbackByPropertyId(10L);

        assertEquals(1, results.size());
        assertEquals("Outstanding property!", results.get(0).getComments());
    }

    @Test
    void deleteFeedback_NotFound_ThrowsException() {
        when(feedbackRepository.existsById(99L)).thenReturn(false);

        assertThrows(FeedbackNotFoundException.class, () -> feedbackService.deleteFeedback(99L));
    }
}
