-- Property Database Schema Script

CREATE TABLE IF NOT EXISTS properties (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    location VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    availability_from DATE,
    availability_to DATE,
    owner_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS amenities (
    id BIGSERIAL PRIMARY KEY,
    property_id BIGINT REFERENCES properties(id) ON DELETE CASCADE,
    amenity_name VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS property_images (
    id BIGSERIAL PRIMARY KEY,
    property_id BIGINT REFERENCES properties(id) ON DELETE CASCADE,
    image_url VARCHAR(500) NOT NULL
);

CREATE TABLE IF NOT EXISTS attractions (
    id BIGSERIAL PRIMARY KEY,
    property_id BIGINT REFERENCES properties(id) ON DELETE CASCADE,
    attraction_name VARCHAR(150) NOT NULL,
    distance VARCHAR(50) NOT NULL
);

-- Sample Data Seeding
INSERT INTO properties (name, description, location, address, availability_from, availability_to, owner_name, created_at)
VALUES 
('Sunset Ocean Villa', 'Luxury beachfront villa with infinity pool and panoramic ocean views.', 'Malibu', '789 Ocean Highway, Malibu, CA', '2026-01-01', '2026-12-31', 'Robert Vance', CURRENT_TIMESTAMP),
('Alpine Mountain Lodge', 'Cozy wooden chalet situated near top ski resorts and mountain hiking trails.', 'Aspen', '101 Pine Needle Rd, Aspen, CO', '2026-01-01', '2026-12-31', 'Elena Rostova', CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;

INSERT INTO amenities (property_id, amenity_name) VALUES 
(1, 'Private Swimming Pool'), (1, 'High-Speed Wi-Fi'), (1, 'Ocean View Balcony'), (1, 'Air Conditioning'),
(2, 'Fireplace'), (2, 'Ski Storage'), (2, 'Hot Tub'), (2, 'Free Parking');

INSERT INTO property_images (property_id, image_url) VALUES 
(1, 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750'),
(2, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb');

INSERT INTO attractions (property_id, attraction_name, distance) VALUES 
(1, 'Zuma Beach', '1.5 km'), (1, 'Malibu Pier', '4.2 km'),
(2, 'Aspen Mountain Ski Resort', '0.8 km'), (2, 'Maroon Bells Hiking Trail', '5.0 km');
