package com.holidayhome.property.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PropertyRequestDTO {

    @NotBlank(message = "Property name is required")
    private String name;

    private String description;

    @NotBlank(message = "Location is required")
    private String location;

    @NotBlank(message = "Address is required")
    private String address;

    @NotNull(message = "Availability start date is required")
    private LocalDate availabilityFrom;

    @NotNull(message = "Availability end date is required")
    private LocalDate availabilityTo;

    @NotBlank(message = "Owner name is required")
    private String ownerName;

    private List<AmenityDTO> amenities;
    private List<PropertyImageDTO> images;
    private List<AttractionDTO> attractions;
}
