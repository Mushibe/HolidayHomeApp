package com.holidayhome.property.controller;

import com.holidayhome.property.dto.ApiResponse;
import com.holidayhome.property.dto.PropertyRequestDTO;
import com.holidayhome.property.dto.PropertyResponseDTO;
import com.holidayhome.property.service.PropertyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/properties")
@RequiredArgsConstructor
@Tag(name = "Property Management Controller", description = "Endpoints for managing and exploring holiday homes and tourist locations")
public class PropertyController {

    private static final Logger log = LoggerFactory.getLogger(PropertyController.class);

    private final PropertyService propertyService;

    @PostMapping
    @Operation(summary = "Add a new property", description = "Admin endpoint to create a new property listing with amenities, images, and attractions")
    public ResponseEntity<ApiResponse<PropertyResponseDTO>> createProperty(@Valid @RequestBody PropertyRequestDTO requestDTO) {
        log.info("REST request to add property: {}", requestDTO.getName());
        PropertyResponseDTO created = propertyService.createProperty(requestDTO);
        return new ResponseEntity<>(ApiResponse.success("Property created successfully", created), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update property", description = "Admin endpoint to update an existing property listing")
    public ResponseEntity<ApiResponse<PropertyResponseDTO>> updateProperty(
            @PathVariable Long id,
            @Valid @RequestBody PropertyRequestDTO requestDTO) {
        log.info("REST request to update property ID: {}", id);
        PropertyResponseDTO updated = propertyService.updateProperty(id, requestDTO);
        return ResponseEntity.ok(ApiResponse.success("Property updated successfully", updated));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete property", description = "Admin endpoint to remove a property listing")
    public ResponseEntity<ApiResponse<Void>> deleteProperty(@PathVariable Long id) {
        log.info("REST request to delete property ID: {}", id);
        propertyService.deleteProperty(id);
        return ResponseEntity.ok(ApiResponse.success("Property deleted successfully", null));
    }

    @GetMapping
    @Operation(summary = "Get all properties", description = "Public endpoint to retrieve all available holiday home properties")
    public ResponseEntity<ApiResponse<List<PropertyResponseDTO>>> getAllProperties() {
        log.info("REST request to fetch all properties");
        List<PropertyResponseDTO> properties = propertyService.getAllProperties();
        return ResponseEntity.ok(ApiResponse.success("Properties retrieved successfully", properties));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get property by ID", description = "Public endpoint to retrieve property details by ID")
    public ResponseEntity<ApiResponse<PropertyResponseDTO>> getPropertyById(@PathVariable Long id) {
        log.info("REST request to fetch property details for ID: {}", id);
        PropertyResponseDTO property = propertyService.getPropertyById(id);
        return ResponseEntity.ok(ApiResponse.success("Property details retrieved successfully", property));
    }

    @GetMapping("/search")
    @Operation(summary = "Search properties", description = "Search holiday homes based on location and date availability")
    public ResponseEntity<ApiResponse<List<PropertyResponseDTO>>> searchProperties(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate) {
        log.info("REST request to search properties by location: {}", location);
        List<PropertyResponseDTO> results = propertyService.searchProperties(location, fromDate, toDate);
        return ResponseEntity.ok(ApiResponse.success("Property search completed", results));
    }
}
