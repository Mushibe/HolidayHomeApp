package com.holidayhome.property.mapper;

import com.holidayhome.property.dto.AmenityDTO;
import com.holidayhome.property.dto.AttractionDTO;
import com.holidayhome.property.dto.PropertyImageDTO;
import com.holidayhome.property.dto.PropertyRequestDTO;
import com.holidayhome.property.dto.PropertyResponseDTO;
import com.holidayhome.property.entity.AmenityEntity;
import com.holidayhome.property.entity.AttractionEntity;
import com.holidayhome.property.entity.PropertyEntity;
import com.holidayhome.property.entity.PropertyImageEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.stream.Collectors;

@Component
public class PropertyMapper {

    public PropertyEntity toEntity(PropertyRequestDTO dto) {
        if (dto == null) {
            return null;
        }

        PropertyEntity entity = PropertyEntity.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .location(dto.getLocation())
                .address(dto.getAddress())
                .availabilityFrom(dto.getAvailabilityFrom())
                .availabilityTo(dto.getAvailabilityTo())
                .ownerName(dto.getOwnerName())
                .build();

        if (dto.getAmenities() != null) {
            dto.getAmenities().forEach(a -> entity.addAmenity(
                    AmenityEntity.builder().amenityName(a.getAmenityName()).build()
            ));
        }

        if (dto.getImages() != null) {
            dto.getImages().forEach(img -> entity.addImage(
                    PropertyImageEntity.builder().imageUrl(img.getImageUrl()).build()
            ));
        }

        if (dto.getAttractions() != null) {
            dto.getAttractions().forEach(att -> entity.addAttraction(
                    AttractionEntity.builder()
                            .attractionName(att.getAttractionName())
                            .distance(att.getDistance())
                            .build()
            ));
        }

        return entity;
    }

    public PropertyResponseDTO toDTO(PropertyEntity entity) {
        if (entity == null) {
            return null;
        }

        return PropertyResponseDTO.builder()
                .id(entity.getId())
                .name(entity.getName())
                .description(entity.getDescription())
                .location(entity.getLocation())
                .address(entity.getAddress())
                .availabilityFrom(entity.getAvailabilityFrom())
                .availabilityTo(entity.getAvailabilityTo())
                .ownerName(entity.getOwnerName())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .amenities(entity.getAmenities() != null ?
                        entity.getAmenities().stream()
                                .map(a -> AmenityDTO.builder().id(a.getId()).amenityName(a.getAmenityName()).build())
                                .collect(Collectors.toList()) : Collections.emptyList())
                .images(entity.getImages() != null ?
                        entity.getImages().stream()
                                .map(i -> PropertyImageDTO.builder().id(i.getId()).imageUrl(i.getImageUrl()).build())
                                .collect(Collectors.toList()) : Collections.emptyList())
                .attractions(entity.getAttractions() != null ?
                        entity.getAttractions().stream()
                                .map(att -> AttractionDTO.builder().id(att.getId()).attractionName(att.getAttractionName()).distance(att.getDistance()).build())
                                .collect(Collectors.toList()) : Collections.emptyList())
                .build();
    }
}
