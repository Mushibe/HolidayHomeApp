package com.holidayhome.property.repository;

import com.holidayhome.property.entity.PropertyEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PropertyRepository extends JpaRepository<PropertyEntity, Long>, JpaSpecificationExecutor<PropertyEntity> {

    List<PropertyEntity> findByLocationContainingIgnoreCase(String location);

    @Query("SELECT DISTINCT p FROM PropertyEntity p LEFT JOIN p.amenities a LEFT JOIN p.attractions att " +
           "WHERE (:location IS NULL OR LOWER(p.location) LIKE LOWER(CONCAT('%', :location, '%'))) " +
           "AND (:fromDate IS NULL OR p.availabilityFrom <= :fromDate) " +
           "AND (:toDate IS NULL OR p.availabilityTo >= :toDate)")
    List<PropertyEntity> searchProperties(
            @Param("location") String location,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate
    );
}
