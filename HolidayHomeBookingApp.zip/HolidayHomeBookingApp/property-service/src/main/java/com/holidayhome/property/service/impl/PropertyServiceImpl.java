package com.holidayhome.property.service.impl;

import com.holidayhome.property.dto.AmenityDTO;
import com.holidayhome.property.dto.AttractionDTO;
import com.holidayhome.property.dto.PropertyImageDTO;
import com.holidayhome.property.dto.PropertyRequestDTO;
import com.holidayhome.property.dto.PropertyResponseDTO;
import com.holidayhome.property.entity.AmenityEntity;
import com.holidayhome.property.entity.AttractionEntity;
import com.holidayhome.property.entity.PropertyEntity;
import com.holidayhome.property.entity.PropertyImageEntity;
import com.holidayhome.property.exception.PropertyNotFoundException;
import com.holidayhome.property.mapper.PropertyMapper;
import com.holidayhome.property.repository.PropertyRepository;
import com.holidayhome.property.service.PropertyService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PropertyServiceImpl implements PropertyService {

    private static final Logger log = LoggerFactory.getLogger(PropertyServiceImpl.class);

    private final PropertyRepository propertyRepository;
    private final PropertyMapper propertyMapper;

    @Override
    @Transactional
    public PropertyResponseDTO createProperty(PropertyRequestDTO requestDTO) {
        log.info("Creating property with name: {}", requestDTO.getName());
        PropertyEntity entity = propertyMapper.toEntity(requestDTO);
        PropertyEntity saved = propertyRepository.save(entity);
        log.info("Property created successfully with ID: {}", saved.getId());
        return propertyMapper.toDTO(saved);
    }

    @Override
    @Transactional
    public PropertyResponseDTO updateProperty(Long id, PropertyRequestDTO requestDTO) {
        log.info("Updating property ID: {}", id);
        PropertyEntity existing = propertyRepository.findById(id)
                .orElseThrow(() -> new PropertyNotFoundException("Property not found with ID: " + id));

        existing.setName(requestDTO.getName());
        existing.setDescription(requestDTO.getDescription());
        existing.setLocation(requestDTO.getLocation());
        existing.setAddress(requestDTO.getAddress());
        existing.setAvailabilityFrom(requestDTO.getAvailabilityFrom());
        existing.setAvailabilityTo(requestDTO.getAvailabilityTo());
        existing.setOwnerName(requestDTO.getOwnerName());

        // Clear existing children and re-populate
        existing.getAmenities().clear();
        if (requestDTO.getAmenities() != null) {
            for (AmenityDTO a : requestDTO.getAmenities()) {
                existing.addAmenity(AmenityEntity.builder().amenityName(a.getAmenityName()).build());
            }
        }

        existing.getImages().clear();
        if (requestDTO.getImages() != null) {
            for (PropertyImageDTO img : requestDTO.getImages()) {
                existing.addImage(PropertyImageEntity.builder().imageUrl(img.getImageUrl()).build());
            }
        }

        existing.getAttractions().clear();
        if (requestDTO.getAttractions() != null) {
            for (AttractionDTO att : requestDTO.getAttractions()) {
                existing.addAttraction(AttractionEntity.builder()
                        .attractionName(att.getAttractionName())
                        .distance(att.getDistance())
                        .build());
            }
        }

        PropertyEntity updated = propertyRepository.save(existing);
        log.info("Property ID {} updated successfully", updated.getId());

        return propertyMapper.toDTO(updated);
    }

    @Override
    @Transactional
    public void deleteProperty(Long id) {
        log.info("Deleting property ID: {}", id);
        if (!propertyRepository.existsById(id)) {
            throw new PropertyNotFoundException("Property not found with ID: " + id);
        }
        propertyRepository.deleteById(id);
        log.info("Property ID {} deleted successfully", id);
    }

    @Override
    @Transactional(readOnly = true)
    public PropertyResponseDTO getPropertyById(Long id) {
        log.info("Fetching property by ID: {}", id);
        PropertyEntity entity = propertyRepository.findById(id)
                .orElseThrow(() -> new PropertyNotFoundException("Property not found with ID: " + id));
        return propertyMapper.toDTO(entity);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PropertyResponseDTO> getAllProperties() {
        log.info("Fetching all properties");
        return propertyRepository.findAll().stream()
                .map(propertyMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PropertyResponseDTO> searchProperties(String location, LocalDate fromDate, LocalDate toDate) {
        log.info("Searching properties with location: {}, fromDate: {}, toDate: {}", location, fromDate, toDate);
        return propertyRepository.searchProperties(location, fromDate, toDate).stream()
                .map(propertyMapper::toDTO)
                .collect(Collectors.toList());
    }
}
