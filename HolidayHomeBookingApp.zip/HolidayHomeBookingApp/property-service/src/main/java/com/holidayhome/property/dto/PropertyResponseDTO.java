package com.holidayhome.property.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PropertyResponseDTO {

    private Long id;
    private String name;
    private String description;
    private String location;
    private String address;
    private LocalDate availabilityFrom;
    private LocalDate availabilityTo;
    private String ownerName;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private List<AmenityDTO> amenities;
    private List<PropertyImageDTO> images;
    private List<AttractionDTO> attractions;
}
