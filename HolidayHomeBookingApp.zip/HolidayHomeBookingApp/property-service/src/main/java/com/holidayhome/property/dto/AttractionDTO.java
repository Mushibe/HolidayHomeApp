package com.holidayhome.property.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttractionDTO {

    private Long id;

    @NotBlank(message = "Attraction name is required")
    private String attractionName;

    @NotBlank(message = "Distance is required")
    private String distance;
}
