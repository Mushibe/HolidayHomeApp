package com.holidayhome.property.service;

import com.holidayhome.property.dto.PropertyRequestDTO;
import com.holidayhome.property.dto.PropertyResponseDTO;

import java.time.LocalDate;
import java.util.List;

public interface PropertyService {

    PropertyResponseDTO createProperty(PropertyRequestDTO requestDTO);

    PropertyResponseDTO updateProperty(Long id, PropertyRequestDTO requestDTO);

    void deleteProperty(Long id);

    PropertyResponseDTO getPropertyById(Long id);

    List<PropertyResponseDTO> getAllProperties();

    List<PropertyResponseDTO> searchProperties(String location, LocalDate fromDate, LocalDate toDate);
}
