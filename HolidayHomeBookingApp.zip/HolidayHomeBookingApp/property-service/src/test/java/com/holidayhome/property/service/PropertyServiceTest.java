package com.holidayhome.property.service;

import com.holidayhome.property.dto.PropertyRequestDTO;
import com.holidayhome.property.dto.PropertyResponseDTO;
import com.holidayhome.property.entity.PropertyEntity;
import com.holidayhome.property.exception.PropertyNotFoundException;
import com.holidayhome.property.mapper.PropertyMapper;
import com.holidayhome.property.repository.PropertyRepository;
import com.holidayhome.property.service.impl.PropertyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PropertyServiceTest {

    @Mock
    private PropertyRepository propertyRepository;

    @Mock
    private PropertyMapper propertyMapper;

    @InjectMocks
    private PropertyServiceImpl propertyService;

    private PropertyEntity propertyEntity;
    private PropertyRequestDTO propertyRequestDTO;
    private PropertyResponseDTO propertyResponseDTO;

    @BeforeEach
    void setUp() {
        propertyEntity = PropertyEntity.builder()
                .id(1L)
                .name("Ocean Villa")
                .location("Malibu")
                .address("789 Ocean Rd")
                .availabilityFrom(LocalDate.of(2026, 1, 1))
                .availabilityTo(LocalDate.of(2026, 12, 31))
                .ownerName("John Vance")
                .build();

        propertyRequestDTO = PropertyRequestDTO.builder()
                .name("Ocean Villa")
                .location("Malibu")
                .address("789 Ocean Rd")
                .availabilityFrom(LocalDate.of(2026, 1, 1))
                .availabilityTo(LocalDate.of(2026, 12, 31))
                .ownerName("John Vance")
                .build();

        propertyResponseDTO = PropertyResponseDTO.builder()
                .id(1L)
                .name("Ocean Villa")
                .location("Malibu")
                .build();
    }

    @Test
    void createProperty_Success() {
        when(propertyMapper.toEntity(any())).thenReturn(propertyEntity);
        when(propertyRepository.save(any())).thenReturn(propertyEntity);
        when(propertyMapper.toDTO(any())).thenReturn(propertyResponseDTO);

        PropertyResponseDTO result = propertyService.createProperty(propertyRequestDTO);

        assertNotNull(result);
        assertEquals("Ocean Villa", result.getName());
    }

    @Test
    void getPropertyById_Success() {
        when(propertyRepository.findById(1L)).thenReturn(Optional.of(propertyEntity));
        when(propertyMapper.toDTO(propertyEntity)).thenReturn(propertyResponseDTO);

        PropertyResponseDTO result = propertyService.getPropertyById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    @Test
    void getPropertyById_NotFound_ThrowsException() {
        when(propertyRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(PropertyNotFoundException.class, () -> propertyService.getPropertyById(99L));
    }

    @Test
    void deleteProperty_Success() {
        when(propertyRepository.existsById(1L)).thenReturn(true);

        propertyService.deleteProperty(1L);

        verify(propertyRepository).deleteById(1L);
    }
}
